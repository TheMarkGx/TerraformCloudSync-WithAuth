import boto3
import os
import json

s3 = boto3.client("s3")
bucket = os.environ["BUCKET_NAME"]
MAX_S3_VERSIONS = int(os.getenv("MAX_S3_VERSIONS", 10)) #Configurable, how many backup copies of an app state file will this deployment allow

### Supports minimal Exception logging to AWS Cloudwatch logs via print, later can change to import logging, and json dump into a logger object to log/trace the key that errored

def main(event, context):
    path = event.get("rawPath", "")
    method = event.get("requestContext", {}).get("http", {}).get("method", "")
    query = event.get("queryStringParameters", {}) or {}

    key = query.get("key")
    if not key:
        return {
            "statusCode": 400, #Client side issue if triggered
            "body": "Missing required query parameter: key (full s3 file path)"
        }

    ### If any more routing paths are added in APIgateway*.tf, add the handlers here
    if method == "POST" and path == "/upload":
        return handle_upload(key)
        
    elif method == "GET" and path == "/download":
        return handle_download(key)
    
    elif method == "DELETE" and path == "/delete":
        return handle_delete(key)

    else:
        return {
            "statusCode": 404, #Client side issue if triggered
            "body": "Route not supported (method typo? Bad path?)"
        }

def handle_upload(key):
    # Enforce max versions for this key
    try:
        versions = s3.list_object_versions(Bucket=bucket, Prefix=key).get("Versions", [])
        versions = sorted(versions, key=lambda v: v["LastModified"], reverse=True)

        if len(versions) > MAX_S3_VERSIONS:
            delete_keys = [{"Key": key, "VersionId": v["VersionId"]} for v in versions[MAX_S3_VERSIONS:]]
            s3.delete_objects(Bucket=bucket, Delete={"Objects": delete_keys})
    except Exception as e:
        # Don't block upload URL just because cleanup failed, later can implement a regularly scheduled AWS based audit solution to correct these instances
        print(f"Version cleanup failed: {e}")

    url = s3.generate_presigned_url(
        ClientMethod="put_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=900
    )

    return {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json" },
        "body": json.dumps({"url": url})
    }

def handle_download(key):
    url = s3.generate_presigned_url(
        ClientMethod="get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=900
    )

    return {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json" },
        "body": json.dumps({"url": url})
    }

def handle_delete(key):
    try:
        s3.delete_object(Bucket=bucket, Key=key)
        return {
            "statusCode": 200,
            "headers": { "Content-Type": "application/json" },
            "body": json.dumps({"deleted": key})
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Failed to delete key: {str(e)}"})
        }
